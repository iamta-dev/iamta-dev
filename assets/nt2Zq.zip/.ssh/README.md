# SSH-KEY


```
sudo apt install git-all
cd .ssh 
chmod 600 * 
eval $(ssh-agent -s) 
ssh-add id_rsa_odds
git clone my_repo 

git config --global user.name "taZgg"
git config --global user.email "natthawat.narin@odds.team"
cat .gitconfig
```

### wsl
```
explorer.exe .
sudo ln -s /mnt/c/Users/USER/.ssh ~/.ssh
chmod 600 * 
eval $(ssh-agent -s) 
ssh-add id_rsa_odds
```


